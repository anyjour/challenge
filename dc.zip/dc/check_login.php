<?php
session_start();
$response = [
    'logged_in' => false
];

if (isset($_SESSION['name'])) {
    $response['logged_in'] = true;
    $response['name'] = $_SESSION['name'];
	$response['id'] = $_SESSION['user_id'];
}

echo json_encode($response);
?>
