<?php
$servername = "localhost";
$username = "root";
$password = "9rBYa0zwIl9QUG9L";
$dbname = "challenge";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

?>
