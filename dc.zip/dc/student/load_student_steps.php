<?php
include '../db.php';
include 'student_check.php';


$level_id = $_GET['level_id'];


$sql = "SELECT s.id, s.step_name, s.step_describe, p.score, p.passed
        FROM steps s
        LEFT JOIN (
            SELECT step_id, MAX(id) as latest_progress_id
            FROM progress
            WHERE user_id = $user_id
            GROUP BY step_id
        ) lp ON s.id = lp.step_id
        LEFT JOIN progress p ON lp.latest_progress_id = p.id
        WHERE s.level_id = $level_id
        ORDER BY s.sort_by";

$result = $conn->query($sql);

$steps = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $steps[] = [
            'id' => $row['id'],
            'step_name' => $row['step_name'],
            'passed' => isset($row['passed']) ? $row['passed'] : 0
        ];
    }
}

$response = [
    'steps' => $steps
];



header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
