<?php 
include '../db.php'; 
include 'student_check.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>学生闯关进度</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/layer/3.5.1/theme/default/layer.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/layer/3.5.1/layer.js"></script>
    <style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    padding: 20px;
}
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}
.header .user-info {
    font-size: 16px;
    color: #333;
}
.header .logout {
    background-color: #dc3545;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
}
.header .logout:hover {
    background-color: #c82333;
}
h2 {
    margin-top: 0;
    color: #333;
}
.container {
    display: flex;
}
.sidebar {
    width: 200px;
    margin-right: 20px;
}
.content {
    flex: 1;
}
.category {
    padding: 10px;
    border: 1px solid #ddd;
    background: #fff;
    margin-bottom: 10px;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.category.selected {
    border-color: #007bff;
}
.category .checkmark {
    display: none;
    color: #28a745;
}
.category.completed .checkmark {
    display: inline;
}
.level-container {
    display: flex;
    flex-wrap: wrap;
}
.level {
    width: 150px;
    height: 150px;
    border: 1px solid #ddd;
    background: #fff;
    margin: 10px;
    padding: 10px;
    border-radius: 4px;
    text-align: center;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: relative;
}
.level.selected {
    border-color: #007bff;
}
.level .checkmark {
    display: none;
    color: #28a745;
    position: absolute;
    top: 10px;
    right: 10px;
}
.level.completed .checkmark {
    display: inline;
}
.level .lock-icon {
    position: absolute;
    top: 10px;
    right: 10px;
    filter: grayscale(100%);
}
.level .in-progress-icon {
    position: absolute;
    top: 10px;
    right: 10px;
    animation: spin 2s linear infinite;
}
.level.completed .lock-icon, .level.completed .in-progress-icon {
    display: none;
}
.level-progress {
    margin-top: 10px;
    font-size: 14px;
    color: #555;
}
.steps-container {
    margin-top: 20px;
    display: flex;
    flex-wrap: wrap;
}
.step {
    width: 150px;
    height: 45px;
    border: 1px solid #ddd;
    background: #fff;
    margin: 10px;
    padding: 10px;
    border-radius: 4px;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: relative;
}
.step.completed {
    border-color: #28a745;
}
.step.not-completed {
    border-color: #dc3545;
}
.step .checkmark, .step .lock-icon, .step .in-progress-icon {
    position: absolute;
    top: 10px;
    right: 10px;
}
.step .checkmark {
    display: none;
    color: #28a745;
}
.step.completed .checkmark {
    display: inline;
}
.step .lock-icon {
    filter: grayscale(100%);
}
.step .in-progress-icon {
    color: #007bff; /* 进度图标颜色 */
    animation: spin 2s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
    </style>
</head>
<body>

<div class="header">
    <div class="user-info">欢迎, <span id="username"></span></div>
    <button class="logout" id="logoutButton">退出</button>
</div>

<h2>学生闯关进度</h2>
<div class="container">
    <div class="sidebar">
        <h3>分类</h3>
        <div id="categories-container">
            <!-- 动态生成的分类 -->
        </div>
    </div>
    <div class="content">
        <h3>关卡</h3>
        <div class="level-container" id="levels-container">
            <!-- 动态生成的关卡 -->
        </div>

        <h3>步骤</h3>
        <div class="steps-container" id="steps-container">
            <!-- 动态生成的步骤 -->
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    var userId;

    // 检查用户登录状态
    $.ajax({
        url: '../check_login.php',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.logged_in) {
                userId = response.user_id;
                $('#username').text(response.name + "（ID" + response.id + "）");
                loadCategories();
            } else {
                window.location.href = '../index.html';
            }
        }
    });

    // 加载分类
    function loadCategories() {
        $.ajax({
            url: 'load_categories.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                var categoriesHtml = '';
                $.each(data, function(index, category) {
                    categoriesHtml += '<div class="category ' + (category.completed ? 'completed' : '') + '" data-id="' + category.id + '">'
                                    + category.category_name
                                    + '<span class="checkmark">✔</span>'
                                    + '</div>';
                });
                $('#categories-container').html(categoriesHtml);
                if (data.length > 0) {
                    var firstCategoryId = data[0].id;
                    selectCategory(firstCategoryId);
                }
            }
        });
    }

    // 加载关卡
    function loadLevels(category_id) {
        if (!category_id) {
            $('#levels-container').html('');
            $('#steps-container').html('');
            return;
        }
        $.ajax({
            url: 'load_student_levels.php',
            type: 'GET',
            data: {category_id: category_id, user_id: userId},
            dataType: 'json',
            success: function(data) {
                var levelsHtml = '';
                var unlockNext = false;
                $.each(data.levels, function(index, level) {
                    var isCompleted = level.steps_completed == level.total_steps;
                    var unlockCurrent = unlockNext || index === 0;
                    unlockNext = isCompleted;

                    levelsHtml += '<div class="level ' + (isCompleted ? 'completed' : '') + '" data-id="' + level.id + '">'
                                + '<div>' + level.level_name + '</div>'
                                + '<div class="level-progress">' + level.steps_completed + '/' + level.total_steps + '</div>'
                                + '<span class="checkmark">✔</span>'
                                + (isCompleted ? '' : (unlockCurrent ? '<span class="in-progress-icon">⏳</span>' : '<span class="lock-icon">🔒</span>'))
                                + '</div>';
                });
                $('#levels-container').html(levelsHtml);
                if (data.currentLevelId) {
                    selectLevel(data.currentLevelId);
                }
            }
        });
    }

    // 加载步骤
    function loadSteps(level_id) {
        if (!level_id) {
            $('#steps-container').html('');
            return;
        }
        $.ajax({
            url: 'load_student_steps.php',
            type: 'GET',
            data: {level_id: level_id, user_id: userId},
            dataType: 'json',
            success: function(data) {
                var stepsHtml = '';
                var unlockNext = false;
                var parentLevelUnlocked = $('.level[data-id="' + level_id + '"]').find('.in-progress-icon').length > 0;

                $.each(data.steps, function(index, step) {
                    var isCompleted = step.passed;
                    var unlockCurrent = unlockNext || (index === 0 && parentLevelUnlocked);
                    unlockNext = isCompleted;

                    stepsHtml += '<div class="step ' + (isCompleted ? 'completed' : 'not-completed') + '" data-id="' + step.id + '">'
                               + '<div>' + step.step_name + '</div>'
                               + '<span class="checkmark">✔</span>'
                               + (isCompleted ? '' : (unlockCurrent ? '<span class="in-progress-icon">⏳</span>' : '<span class="lock-icon">🔒</span>'))
                               + '</div>';
                });
                $('#steps-container').html(stepsHtml);
            }
        });
    }

    // 选择分类
    function selectCategory(category_id) {
        $('.category').removeClass('selected');
        $('.category[data-id="' + category_id + '"]').addClass('selected');
        $('#steps-container').html(''); // 清空步骤列表
        loadLevels(category_id);
    }

    // 选择关卡
    function selectLevel(level_id) {
        $('.level').removeClass('selected');
        $('.level[data-id="' + level_id + '"]').addClass('selected');
        loadSteps(level_id);
    }

    // 事件：点击分类
    $('#categories-container').on('click', '.category', function() {
        var category_id = $(this).data('id');
        selectCategory(category_id);
    });

    // 事件：点击关卡
    $('#levels-container').on('click', '.level', function() {
        var level_id = $(this).data('id');
        selectLevel(level_id);
    });

    // 事件：退出登录
    $('#logoutButton').click(function() {
        $.ajax({
            url: '../logout.php',
            type: 'GET',
            success: function(response) {
                window.location.href = '../index.html';
            }
        });
    });
});
</script>

</body>
</html>
