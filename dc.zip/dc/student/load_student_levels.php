<?php
include '../db.php';
include 'student_check.php';

$category_id = $_GET['category_id'];

$sql = "SELECT l.id, l.level_name, l.level_describe, l.sort_by,
               (SELECT COUNT(*) FROM steps s WHERE s.level_id = l.id) as total_steps,
               IFNULL((SELECT COUNT(DISTINCT p.step_id) FROM progress p
                       JOIN (SELECT step_id, MAX(id) as max_id FROM progress GROUP BY step_id) max_progress
                       ON p.id = max_progress.max_id
                       WHERE p.user_id = $user_id AND p.passed = 1 AND p.step_id IN (SELECT id FROM steps WHERE level_id = l.id)), 0) as steps_completed
        FROM levels l
        WHERE l.category_id = $category_id
        ORDER BY l.sort_by";

$result = $conn->query($sql);

$levels = [];
$currentLevelId = null;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $levels[] = $row;
        if (is_null($currentLevelId) && $row['steps_completed'] < $row['total_steps']) {
            $currentLevelId = $row['id'];
        }
    }
}

$response = [
    'levels' => $levels,
    'currentLevelId' => $currentLevelId
];

header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
