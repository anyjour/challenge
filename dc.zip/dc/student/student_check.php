<?php

// 检查用户角色是否为管理员
if ($user_role !== 'student') {
    // 如果用户不是管理员，则重定向到登录页面或显示错误信息
    header("Location: ../index.html");
    exit();
}
?>