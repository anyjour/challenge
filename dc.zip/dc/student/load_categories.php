<?php
include '../db.php';
include 'student_check.php';

$sql = "SELECT id, category_name FROM categories ORDER BY sort_by ASC";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $category_id = $row['id'];

        // 检查分类下所有关卡和步骤是否已完成
        $sql_levels = "SELECT l.id
                       FROM levels l
                       WHERE l.category_id = $category_id";
        $result_levels = $conn->query($sql_levels);

        $all_completed = true;
        if ($result_levels->num_rows > 0) {
            while($level = $result_levels->fetch_assoc()) {
                $level_id = $level['id'];

                $sql_steps = "SELECT s.id, IFNULL(p.passed, 0) as passed
                              FROM steps s
                              LEFT JOIN (
                                  SELECT step_id, MAX(id) as latest_progress_id
                                  FROM progress
                                  WHERE user_id = $user_id
                                  GROUP BY step_id
                              ) lp ON s.id = lp.step_id
                              LEFT JOIN progress p ON lp.latest_progress_id = p.id
                              WHERE s.level_id = $level_id
                              ORDER BY s.sort_by";
                $result_steps = $conn->query($sql_steps);

                if ($result_steps->num_rows > 0) {
                    while($step = $result_steps->fetch_assoc()) {
                        if ($step['passed'] == 0) {
                            $all_completed = false;
                            break 2;
                        }
                    }
                } else {
                    $all_completed = false;
                    break;
                }
            }
        } else {
            $all_completed = false;
        }

        $row['completed'] = $all_completed;
        $categories[] = $row;
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($categories, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
