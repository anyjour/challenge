<?php
include '../db.php';

$category_id = $_GET['id'];

// 检查分类下是否有关联的关卡
$sql = "SELECT COUNT(*) as count FROM levels WHERE category_id = $category_id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$response = [
    'has_levels' => $row['count'] > 0
];

header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
