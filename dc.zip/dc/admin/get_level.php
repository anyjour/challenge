<?php
include '../db.php';
include 'admin_check.php';

$id = $_GET['id'];
$sql = "SELECT * FROM levels WHERE id = $id";
$result = $conn->query($sql);

header('Content-Type: application/json; charset=utf-8');

if ($result->num_rows > 0) {
    echo json_encode($result->fetch_assoc(), JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([]);
}

$conn->close();
?>
