<?php
include '../db.php';
include 'admin_check.php';

header('Content-Type: application/json; charset=utf-8');

$id = $_GET['id'];

// 使用预处理语句防止 SQL 注入
$sql = $conn->prepare("SELECT * FROM steps WHERE id = ?");
$sql->bind_param("i", $id);
$sql->execute();
$result = $sql->get_result();

if ($result->num_rows > 0) {
    echo json_encode($result->fetch_assoc(), JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([]);
}

$sql->close();
$conn->close();
?>
