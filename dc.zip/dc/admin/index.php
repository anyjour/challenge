<?php 
include '../db.php'; 
include 'admin_check.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>分类、关卡和步骤管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/layer/3.5.1/theme/default/layer.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/layer/3.5.1/layer.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        h2 {
            margin-top: 0;
            color: #333;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        li {
            margin: 0 0 10px;
            padding: 10px;
            border: 1px solid #ddd;
            background: #fff;
            cursor: move;
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .header .user-info {
            font-size: 16px;
            color: #333;
        }
        .header .logout {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .header .logout:hover {
            background-color: #c82333;
        }
        .item-content {
            flex: 1;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .item-buttons {
            display: flex;
            align-items: center;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 5px;
        }
        button:hover {
            background-color: #0056b3;
        }
        button.delete-level, button.delete-step,button.delete-category {
            background-color: #dc3545;
        }
        button.delete-level:hover, button.delete-step:hover,button.delete-category:hover {
            background-color: #c82333;
        }
        #add-level, #add-step,#add-category {
            background-color: #28a745;
            margin-bottom: 20px;
        }
        #add-level:hover, #add-step:hover,#add-category:hover {
            background-color: #218838;
        }
        .form-container {
            padding: 20px;
            background: #fff;
            border-radius: 4px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="number"], select, textarea {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea {
            height: 100px;
        }
        .container {
            display: flex;
            justify-content: space-between;
        }
        .column {
            width: 48%;
        }
        @media (max-width: 600px) {
            body {
                padding: 10px;
            }
            button {
                padding: 5px;
                font-size: 14px;
            }
            .form-container {
                padding: 10px;
            }
            label, input[type="text"], input[type="number"], select, textarea {
                font-size: 14px;
            }
            textarea {
                height: 80px;
            }
            #add-level, #add-step {
                padding: 10px;
                font-size: 14px;
            }
            .container {
                flex-direction: column;
            }
            .column {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="header">
    <div class="user-info">欢迎, <span id="username"></span></div>
    <button class="logout" id="logoutButton">退出</button>
</div>
<h2>分类</h2>
<ul id="categories-list">
    <!-- 动态生成的分类列表 -->
</ul>
<button id="add-category">添加分类</button>

<div class="container">
    <div class="column">
        <h2>关卡</h2>
        <select id="category-select">
            <option value="">选择分类</option>
        </select>
        <ul id="levels-list">
            <!-- 动态生成的关卡列表 -->
        </ul>
        <button id="add-level">添加关卡</button>
    </div>
    <div class="column">
        <h2>步骤</h2>
        <select id="level-select">
            <option value="">选择关卡</option>
        </select>
        <ul id="steps-list">
            <!-- 动态生成的步骤列表 -->
        </ul>
        <button id="add-step">添加步骤</button>
    </div>
</div>

<!-- 隐藏的弹出层表单 -->
<div id="category-form" style="display: none;">
    <div class="form-container">
        <form id="categoryForm">
            <input type="hidden" id="category-id" name="id">
            <label for="category_name">分类名称:</label>
            <input type="text" id="category_name" name="category_name"><br>
            <label for="category_describe">分类描述:</label>
            <input type="text" id="category_describe" name="category_describe"><br>
            <button type="submit">提交</button>
        </form>
    </div>
</div>

<div id="level-form" style="display: none;">
    <div class="form-container">
        <form id="levelForm">
            <input type="hidden" id="level-id" name="id">
            <input type="hidden" id="category_id" name="category_id">
            <label for="level_name">关卡名称:</label>
            <input type="text" id="level_name" name="level_name"><br>
            <label for="level_describe">关卡描述:</label>
            <input type="text" id="level_describe" name="level_describe"><br>
            <button type="submit">提交</button>
        </form>
    </div>
</div>

<div id="step-form" style="display: none;">
    <div class="form-container">
        <form id="stepForm">
            <input type="hidden" id="step-id" name="id">
            <input type="hidden" id="level_id" name="level_id">
            <label for="step_name">步骤名称:</label>
            <input type="text" id="step_name" name="step_name"><br>
            <label for="step_describe">步骤描述:</label>
            <input type="text" id="step_describe" name="step_describe"><br>
            <label for="step_data">步骤数据:</label>
            <textarea id="step_data" name="step_data"></textarea><br>
            <button type="submit">提交</button>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    loadCategories();

    // Load categories
    function loadCategories() {
        $.ajax({
            url: 'load_categories.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                var categoriesHtml = '';
                var categoryOptions = '<option value="">选择分类</option>';
                $.each(data, function(index, category) {
                    categoriesHtml += '<li data-id="' + category.id + '"><div class="item-content">' + category.category_name + '<div class="item-buttons"><button class="edit-category" data-id="' + category.id + '">编辑</button> <button class="delete-category" data-id="' + category.id + '">删除</button></div></div></li>';
                    categoryOptions += '<option value="' + category.id + '">' + category.category_name + '</option>';
                });
                $('#categories-list').html(categoriesHtml);
                $('#category-select').html(categoryOptions);
                makeCategoriesSortable();
            }
        });
    }

    // Load levels for a specific category
    function loadLevels(category_id) {
        if (!category_id) {
            $('#levels-list').html('');
            $('#steps-list').html('');
            return;
        }
        $.ajax({
            url: 'load_levels.php',
            type: 'GET',
            data: {category_id: category_id},
            dataType: 'json',
            success: function(data) {
                var levelsHtml = '';
                var levelOptions = '<option value="">选择关卡</option>';
                $.each(data, function(index, level) {
                    levelsHtml += '<li data-id="' + level.id + '"><div class="item-content">' + level.level_name + '<div class="item-buttons"><button class="edit-level" data-id="' + level.id + '">编辑</button> <button class="delete-level" data-id="' + level.id + '">删除</button></div></div></li>';
                    levelOptions += '<option value="' + level.id + '">' + level.level_name + '</option>';
                });
                $('#levels-list').html(levelsHtml);
                $('#level-select').html(levelOptions);
                makeLevelsSortable();
            }
        });
    }

    // Load steps for a specific level
    function loadSteps(level_id) {
        if (!level_id) {
            $('#steps-list').html('');
            return;
        }
        $.ajax({
            url: 'load_steps.php',
            type: 'GET',
            data: {level_id: level_id},
            dataType: 'json',
            success: function(data) {
                var stepsHtml = '';
                $.each(data, function(index, step) {
                    stepsHtml += '<li data-id="' + step.id + '"><div class="item-content">' + step.step_name + '<div class="item-buttons"><button class="edit-step" data-id="' + step.id + '">编辑</button> <button class="delete-step" data-id="' + step.id + '">删除</button></div></div></li>';
                });
                $('#steps-list').html(stepsHtml);
                makeStepsSortable();
            }
        });
    }

    // Make categories sortable
    function makeCategoriesSortable() {
        $('#categories-list').sortable({
            update: function(event, ui) {
                var ids = $(this).sortable('toArray', {attribute: 'data-id'});
                $.post('category.php', {action: 'sort', ids: ids}, function(response) {
                    loadCategories();
                });
            }
        });
    }

    // Make levels sortable
    function makeLevelsSortable() {
        $('#levels-list').sortable({
            update: function(event, ui) {
                var ids = $(this).sortable('toArray', {attribute: 'data-id'});
                $.post('level.php', {action: 'sort', ids: ids}, function(response) {
                    loadLevels($('#category-select').val());
                });
            }
        });
    }

    // Make steps sortable
    function makeStepsSortable() {
        $('#steps-list').sortable({
            update: function(event, ui) {
                var ids = $(this).sortable('toArray', {attribute: 'data-id'});
                $.post('step.php', {action: 'sort', ids: ids}, function(response) {
                    loadSteps($('#level-select').val());
                });
            }
        });
    }

    // Event: Category select change
    $('#category-select').change(function() {
        var category_id = $(this).val();
        $('#steps-list').html(''); // Clear steps list
        loadLevels(category_id);
    });

    // Event: Level select change
    $('#level-select').change(function() {
        var level_id = $(this).val();
        loadSteps(level_id);
    });

    // Add category
    $('#add-category').click(function() {
        $('#categoryForm')[0].reset();
        $('#category-id').val('');
        var area = ['650px', '450px'];
        if ($(window).width() <= 600) {
            area = ['90%', '90%'];
        }
        layer.open({
            type: 1,
            title: '添加分类',
            area: area,
            content: $('#category-form')
        });
    });

    // Add level
    $('#add-level').click(function() {
        var selectedCategory = $('#category-select').val();
        if (!selectedCategory) {
            alert('请先选择分类。');
            return;
        }
        $('#levelForm')[0].reset();
        $('#level-id').val('');
        $('#category_id').val(selectedCategory);
        var area = ['650px', '450px'];
        if ($(window).width() <= 600) {
            area = ['90%', '90%'];
        }
        layer.open({
            type: 1,
            title: '添加关卡',
            area: area,
            content: $('#level-form')
        });
    });

    // Add step
    $('#add-step').click(function() {
        var selectedLevel = $('#level-select').val();
        if (!selectedLevel) {
            alert('请先选择关卡。');
            return;
        }
        $('#stepForm')[0].reset();
        $('#step-id').val('');
        $('#level_id').val(selectedLevel);
        var area = ['650px', '450px'];
        if ($(window).width() <= 600) {
            area = ['90%', '90%'];
        }
        layer.open({
            type: 1,
            title: '添加步骤',
            area: area,
            content: $('#step-form')
        });
    });

    // Submit category form
    $('#categoryForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        var action = $('#category-id').val() ? 'edit' : 'add';
        $.post('category.php', formData + '&action=' + action, function(response) {
            layer.closeAll();
            loadCategories();
        });
    });

    // Submit level form
    $('#levelForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        var action = $('#level-id').val() ? 'edit' : 'add';
        $.post('level.php', formData + '&action=' + action, function(response) {
            layer.closeAll();
            loadLevels($('#category-select').val());
        });
    });

    // Submit step form
    $('#stepForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        var action = $('#step-id').val() ? 'edit' : 'add';
        $.post('step.php', formData + '&action=' + action, function(response) {
            layer.closeAll();
            loadSteps($('#level-select').val());
        });
    });

    // Edit category
    $('#categories-list').on('click', '.edit-category', function() {
        var id = $(this).data('id');
        $.get('get_category.php', {id: id}, function(data) {
            var category = data;
            $('#category-id').val(category.id);
            $('#category_name').val(category.category_name);
            $('#category_describe').val(category.category_describe);
            var area = ['650px', '450px'];
            if ($(window).width() <= 600) {
                area = ['90%', '90%'];
            }
            layer.open({
                type: 1,
                title: '编辑分类',
                area: area,
                content: $('#category-form')
            });
        });
    });

    // Edit level
    $('#levels-list').on('click', '.edit-level', function() {
        var id = $(this).data('id');
        $.get('get_level.php', {id: id}, function(data) {
            var level = data;
            $('#level-id').val(level.id);
            $('#level_name').val(level.level_name);
            $('#level_describe').val(level.level_describe);
            var area = ['650px', '450px'];
            if ($(window).width() <= 600) {
                area = ['90%', '90%'];
            }
            layer.open({
                type: 1,
                title: '编辑关卡',
                area: area,
                content: $('#level-form')
            });
        });
    });

    // Edit step
    $('#steps-list').on('click', '.edit-step', function() {
        var id = $(this).data('id');
        $.get('get_step.php', {id: id}, function(data) {
            var step = data;
            $('#step-id').val(step.id);
            $('#level_id').val(step.level_id);
            $('#step_name').val(step.step_name);
            $('#step_describe').val(step.step_describe);
            $('#step_data').val(step.step_data);
            var area = ['650px', '450px'];
            if ($(window).width() <= 600) {
                area = ['90%', '90%'];
            }
            layer.open({
                type: 1,
                title: '编辑步骤',
                area: area,
                content: $('#step-form')
            });
        });
    });

    // Delete category
    $('#categories-list').on('click', '.delete-category', function() {
        var id = $(this).data('id');
        $.get('check_category.php', {id: id}, function(response) {
            if (response.has_levels) {
                layer.alert('此分类下还有关联的关卡，无法删除。请先删除关联的关卡。');
            } else {
                layer.confirm('确定要删除此分类吗？', {icon: 3, title: '提示'}, function(index) {
                    $.post('category.php', {action: 'delete', id: id}, function(response) {
                        layer.close(index);
                        loadCategories();
                    });
                });
            }
        });
    });

    // Delete level
    $('#levels-list').on('click', '.delete-level', function() {
        var id = $(this).data('id');
        $.get('check_level.php', {id: id}, function(response) {
            if (response.has_steps) {
                layer.alert('此关卡下还有关联的步骤，无法删除。请先删除关联的步骤。');
            } else {
                layer.confirm('确定要删除此关卡吗？', {icon: 3, title: '提示'}, function(index) {
                    $.post('level.php', {action: 'delete', id: id}, function(response) {
                        layer.close(index);
                        loadLevels($('#category-select').val());
                        $('#steps-list').html(''); // Clear steps list
                    });
                });
            }
        });
    });

    // Delete step
    $('#steps-list').on('click', '.delete-step', function() {
        var id = $(this).data('id');
        var level_id = $('#level-select').val();
        layer.confirm('确定要删除此步骤吗？', {icon: 3, title: '提示'}, function(index) {
            $.post('step.php', {action: 'delete', id: id, level_id: level_id}, function(response) {
                layer.close(index);
                loadSteps($('#level-select').val());
            });
        });
    });
});
</script>
<script>
$(document).ready(function() {
    // 检查用户登录状态
    $.ajax({
        url: '../check_login.php',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.logged_in) {
                $('#username').text(response.name+"（ID"+response.id+"）");
            } else {
                window.location.href = '../index.html';
            }
        }
    });

    // 事件：退出登录
    $('#logoutButton').click(function() {
        $.ajax({
            url: '../logout.php',
            type: 'GET',
            success: function(response) {
                window.location.href = '../index.html';
            }
        });
    });
});
</script>
</body>
</html>
