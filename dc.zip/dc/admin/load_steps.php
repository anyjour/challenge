<?php
include '../db.php';
include 'admin_check.php';

header('Content-Type: application/json; charset=utf-8');

$level_id = $_GET['level_id'];

$sql = "SELECT * FROM steps WHERE level_id = $level_id ORDER BY sort_by";
$result = $conn->query($sql);

$steps = [];
while ($row = $result->fetch_assoc()) {
    $steps[] = $row;
}

echo json_encode($steps, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
