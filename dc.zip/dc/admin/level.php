<?php
include '../db.php';
include 'admin_check.php';

$action = $_POST['action'];

if ($action == 'add') {
    $level_name = $_POST['level_name'];
    $level_describe = $_POST['level_describe'];
    $category_id = $_POST['category_id'];
    $result = $conn->query("SELECT MAX(sort_by) AS max_sort_by FROM levels WHERE category_id = $category_id");
    $row = $result->fetch_assoc();
    $sort_by = $row['max_sort_by'] + 1;
    $sql = "INSERT INTO levels (level_name, level_describe, category_id, sort_by) VALUES ('$level_name', '$level_describe', $category_id, $sort_by)";
    $conn->query($sql);
} elseif ($action == 'edit') {
    $id = $_POST['id'];
    $level_name = $_POST['level_name'];
    $level_describe = $_POST['level_describe'];
    $sql = "UPDATE levels SET level_name = '$level_name', level_describe = '$level_describe' WHERE id = $id";
    $conn->query($sql);
} elseif ($action == 'delete') {
    $id = $_POST['id'];
    $sql = "DELETE FROM levels WHERE id = $id";
    $conn->query($sql);
} elseif ($action == 'sort') {
    $ids = $_POST['ids'];
    foreach ($ids as $index => $id) {
        $sql = "UPDATE levels SET sort_by = $index WHERE id = $id";
        $conn->query($sql);
    }
}

$conn->close();
?>
