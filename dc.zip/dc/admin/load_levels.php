<?php
include '../db.php';
include 'admin_check.php';

header('Content-Type: application/json; charset=utf-8');

$category_id = $_GET['category_id'];

$sql = "SELECT * FROM levels WHERE category_id = $category_id ORDER BY sort_by";
$result = $conn->query($sql);

$levels = [];
while ($row = $result->fetch_assoc()) {
    $levels[] = $row;
}

echo json_encode($levels, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
