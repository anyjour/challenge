<?php
include '../db.php';
include 'admin_check.php';

$action = $_POST['action'];

if ($action == 'add') {
    $category_name = $_POST['category_name'];
    $category_describe = $_POST['category_describe'];
    $result = $conn->query("SELECT MAX(sort_by) AS max_sort_by FROM categories");
    $row = $result->fetch_assoc();
    $sort_by = $row['max_sort_by'] + 1;
    $sql = "INSERT INTO categories (category_name, category_describe, sort_by) VALUES ('$category_name', '$category_describe', $sort_by)";
    $conn->query($sql);
} elseif ($action == 'edit') {
    $id = $_POST['id'];
    $category_name = $_POST['category_name'];
    $category_describe = $_POST['category_describe'];
    $sql = "UPDATE categories SET category_name = '$category_name', category_describe = '$category_describe' WHERE id = $id";
    $conn->query($sql);
} elseif ($action == 'delete') {
    $id = $_POST['id'];
    $sql = "DELETE FROM categories WHERE id = $id";
    $conn->query($sql);
} elseif ($action == 'sort') {
    $ids = $_POST['ids'];
    foreach ($ids as $index => $id) {
        $sql = "UPDATE categories SET sort_by = $index WHERE id = $id";
        $conn->query($sql);
    }
}

$conn->close();
?>
