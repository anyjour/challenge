<?php
include '../db.php';
include 'admin_check.php';

$sql = "SELECT * FROM categories ORDER BY sort_by ASC";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($categories, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
