<?php
include '../db.php';

$level_id = $_GET['id'];

// 检查关卡下是否有关联的步骤
$sql = "SELECT COUNT(*) as count FROM steps WHERE level_id = $level_id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$response = [
    'has_steps' => $row['count'] > 0
];

header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
