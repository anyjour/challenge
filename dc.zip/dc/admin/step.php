<?php
include '../db.php';
include 'admin_check.php';

$action = $_POST['action'];

if ($action == 'add') {
    $step_name = $_POST['step_name'];
    $step_describe = $_POST['step_describe'];
    $step_data = $_POST['step_data'];
    $level_id = $_POST['level_id'];
    $result = $conn->query("SELECT MAX(sort_by) AS max_sort_by FROM steps WHERE level_id = $level_id");
    $row = $result->fetch_assoc();
    $sort_by = $row['max_sort_by'] + 1;
    $sql = "INSERT INTO steps (step_name, step_describe, step_data, level_id, sort_by) VALUES ('$step_name', '$step_describe', '$step_data', $level_id, $sort_by)";
    $conn->query($sql);
} elseif ($action == 'edit') {
    $id = $_POST['id'];
    $step_name = $_POST['step_name'];
    $step_describe = $_POST['step_describe'];
    $step_data = $_POST['step_data'];
    $sql = "UPDATE steps SET step_name = '$step_name', step_describe = '$step_describe', step_data = '$step_data' WHERE id = $id";
    $conn->query($sql);
} elseif ($action == 'delete') {
    $id = $_POST['id'];
    $sql = "DELETE FROM steps WHERE id = $id";
    $conn->query($sql);
} elseif ($action == 'sort') {
    $ids = $_POST['ids'];
    foreach ($ids as $index => $id) {
        $sql = "UPDATE steps SET sort_by = $index WHERE id = $id";
        $conn->query($sql);
    }
}

$conn->close();
?>
