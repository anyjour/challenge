<?php
session_start();
include 'login_db.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT id, user_name, user_role,name FROM users WHERE user_name = ? AND user_password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ss', $username, $password);
$stmt->execute();
$result = $stmt->get_result();

$response = [];
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['username'] = $row['user_name'];
	$_SESSION['name'] = $row['name'];
    $_SESSION['user_role'] = $row['user_role'];
    $response['success'] = true;
    $response['role'] = $row['user_role']; 
	$response['name'] = $row['name'];
	$response['id'] = $row['id'];
} else {
    $response['success'] = false;
    $response['message'] = '无效的用户名或密码';
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
