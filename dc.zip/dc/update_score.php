<?php
include 'db.php'; // 调整路径

$user_id = $_POST['user_id'];
$step_id = $_POST['step_id'];
$score = $_POST['score'];
$passed = $_POST['passed'];

// 插入分数数据
$sql = "INSERT INTO progress (user_id, step_id, score, passed) VALUES ($user_id, $step_id, '$score', '$passed')";
if ($conn->query($sql) === TRUE) {
    // 获取该步骤的关卡ID
    $sql = "SELECT level_id FROM steps WHERE id = $step_id";
    $result = $conn->query($sql);
    if ($result && $row = $result->fetch_assoc()) {
        $level_id = $row['level_id'];

        // 检查该关卡下的所有步骤是否已完成
        $sql = "SELECT steps.id, COALESCE(progress.passed, '0') AS passed
                FROM steps
                LEFT JOIN progress ON progress.step_id = steps.id AND progress.user_id = $user_id
                WHERE steps.level_id = $level_id
                ORDER BY steps.sort_by";
        $result = $conn->query($sql);
        $allCompleted = true;
        while ($row = $result->fetch_assoc()) {
            if ($row['passed'] != '1') {
                $allCompleted = false;
                break;
            }
        }

        // 如果该关卡下的所有步骤都完成，更新 current_level_id
        if ($allCompleted) {
            $conn->query("UPDATE users SET current_level_id = $level_id WHERE id = $user_id");
        }
    }
    echo "Score inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
