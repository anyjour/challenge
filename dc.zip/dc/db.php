<?php
$servername = "localhost";
$username = "root";
$password = "9rBYa0zwIl9QUG9L";
$dbname = "challenge";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

session_start();

// 检查用户是否已登录
if (!isset($_SESSION['user_id'])) {
    // 如果用户未登录，则重定向到登录页面
    header("Location: ../index.html");
    exit();
}

// 获取 user_id 和 user_role
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$username = $_SESSION['username']; 
$name = $_SESSION['name'];
?>
