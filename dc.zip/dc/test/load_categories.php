<?php
include '../db.php';

$sql = "SELECT id, category_name FROM categories ORDER BY sort_by";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $categories[] = [
            'id' => $row['id'],
            'category_name' => $row['category_name']
        ];
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($categories, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
