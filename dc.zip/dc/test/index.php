<?php
include '../db.php';
include '../admin/admin_check.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>测试页面 - 提交成绩</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/layer/3.5.1/theme/default/layer.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/layer/3.5.1/layer.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        select, input[type="text"], input[type="number"] {
            width: 95%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>提交成绩</h2>
    <form id="score-form">
        <label for="user_id">用户ID:</label>
        <select id="user_id" name="user_id" required></select>

        <label for="category_id">分类:</label>
        <select id="category_id" name="category_id" required disabled></select>

        <label for="level_id">关卡:</label>
        <select id="level_id" name="level_id" required disabled></select>

        <label for="step_id">步骤ID:</label>
        <select id="step_id" name="step_id" required disabled></select>

        <label for="score">成绩:</label>
        <input type="number" id="score" name="score" required>

        <button type="submit">提交</button>
    </form>
</div>

<script>
$(document).ready(function() {
    function loadStudents() {
        $.ajax({
            url: 'load_students.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                var options = '<option value="">选择学生</option>';
                $.each(data, function(index, student) {
                    options += '<option value="' + student.id + '">' + student.name + ' (ID: ' + student.id + ')</option>';
                });
                $('#user_id').html(options);
            }
        });
    }

    function loadCategories() {
        $.ajax({
            url: 'load_categories.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                var options = '<option value="">选择分类</option>';
                $.each(data, function(index, category) {
                    options += '<option value="' + category.id + '">' + category.category_name + ' (ID: ' + category.id + ')</option>';
                });
                $('#category_id').html(options);
            }
        });
    }

    function loadLevels(category_id, user_id) {
        if (!category_id || !user_id) {
            $('#level_id').html('<option value="">选择关卡</option>');
            $('#step_id').html('<option value="">选择步骤</option>');
            return;
        }
        $.ajax({
            url: 'load_levels.php',
            type: 'GET',
            data: {category_id: category_id, user_id: user_id},
            dataType: 'json',
            success: function(data) {
                var options = '<option value="">选择关卡</option>';
                $.each(data, function(index, level) {
                    options += '<option value="' + level.id + '">' + level.level_name + ' (ID: ' + level.id + ')' + (level.completed ? ' ✔️' : '') + '</option>';
                });
                $('#level_id').html(options);
                $('#step_id').html('<option value="">选择步骤</option>'); // 清空步骤选项
            },
            error: function(xhr, status, error) {
                console.log('加载关卡失败: ' + error);
            }
        });
    }

    function loadSteps(level_id, user_id) {
        if (!level_id || !user_id) {
            $('#step_id').html('<option value="">选择步骤</option>');
            return;
        }
        $.ajax({
            url: 'load_steps.php',
            type: 'GET',
            data: {level_id: level_id, user_id: user_id},
            dataType: 'json',
            success: function(data) {
                var options = '<option value="">选择步骤</option>';
                $.each(data, function(index, step) {
                    options += '<option value="' + step.id + '">' + step.step_name + ' (ID: ' + step.id + ')' + (step.completed ? ' ✔️' : '') + '</option>';
                });
                $('#step_id').html(options);
            }
        });
    }

    loadStudents();

    $('#user_id').change(function() {
        var user_id = $(this).val();
        if (user_id) {
            $('#category_id').prop('disabled', false);
            loadCategories();
        } else {
            $('#category_id, #level_id, #step_id').prop('disabled', true).html('<option value="">选择...</option>');
        }
    });

    $('#category_id').change(function() {
        var category_id = $(this).val();
        var user_id = $('#user_id').val();
        if (category_id && user_id) {
            $('#level_id').prop('disabled', false);
            loadLevels(category_id, user_id);
        } else {
            $('#level_id, #step_id').prop('disabled', true).html('<option value="">选择...</option>');
        }
    });

    $('#level_id').change(function() {
        var level_id = $(this).val();
        var user_id = $('#user_id').val();
        if (level_id && user_id) {
            $('#step_id').prop('disabled', false);
            loadSteps(level_id, user_id);
        } else {
            $('#step_id').prop('disabled', true).html('<option value="">选择步骤</option>');
        }
    });

    $('#score-form').submit(function(event) {
        event.preventDefault();

        var user_id = $('#user_id').val();
        var step_id = $('#step_id').val();
        var score = $('#score').val();
        var passed = score == 100 ? 1 : 0;

        $.ajax({
            url: '../update_score.php',
            type: 'POST',
            data: {
                user_id: user_id,
                step_id: step_id,
                score: score,
                passed: passed
            },
            success: function(response) {
                layer.alert(response);
                var level_id = $('#level_id').val();
                if (level_id) {
                    loadSteps(level_id, user_id);
                    loadLevels($('#category_id').val(), user_id);
                }
            },
            error: function(xhr, status, error) {
                layer.alert('提交失败: ' + error);
            }
        });
    });
});
</script>

</body>
</html>
