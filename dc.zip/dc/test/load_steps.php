<?php
include '../db.php';

$level_id = $_GET['level_id'];
$user_id = $_GET['user_id'];

$sql = "SELECT s.id, s.step_name, 
               (SELECT COUNT(*) FROM progress p WHERE p.step_id = s.id AND p.user_id = $user_id AND p.passed = 1) as completed
        FROM steps s
        WHERE s.level_id = $level_id ORDER BY s.sort_by";
$result = $conn->query($sql);

$steps = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $steps[] = [
            'id' => $row['id'],
            'step_name' => $row['step_name'],
            'completed' => $row['completed'] > 0
        ];
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($steps, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
