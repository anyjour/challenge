<?php
include '../db.php';

$category_id = $_GET['category_id'];
$user_id = $_GET['user_id'];

$sql = "SELECT l.id, l.level_name, 
               (SELECT COUNT(*) FROM steps s WHERE s.level_id = l.id AND EXISTS 
                    (SELECT 1 FROM progress p WHERE p.step_id = s.id AND p.user_id = $user_id AND p.passed = 1)) as completed
        FROM levels l
        WHERE l.category_id = $category_id ORDER BY l.sort_by";
$result = $conn->query($sql);

$levels = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $levels[] = [
            'id' => $row['id'],
            'level_name' => $row['level_name'],
            'completed' => $row['completed'] > 0
        ];
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($levels, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
