<?php
include '../db.php';

$sql = "SELECT id, name FROM users WHERE user_role = 'student'";
$result = $conn->query($sql);

$students = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($students, JSON_UNESCAPED_UNICODE);

$conn->close();
?>
